"A compiler for Brainfuck+ esotheric language."

__version__ = "0.0.dev0"
