"Executable callback"
import sys
from brainplus import brainplus


if __name__ == "__main__":
    brainplus.main(sys.argv)
    sys.exit(0)
